﻿Public Class frmCustomerForm
    Public Counter As Short
    Private Sub btnCLRLists_Click(sender As Object, e As EventArgs) Handles btnCLRLists.Click
        lstvwCustomerData.Items.Clear()
        lbxCustomerForm.Items.Clear()
    End Sub

    Private Sub btnCloseForm_Click(sender As Object, e As EventArgs) Handles btnCloseForm.Click
        Me.Close()
    End Sub

    Private Sub btnCustomerRecords_Click_Click(sender As Object, e As EventArgs) Handles btnCustomerRecords_Click.Click
        MsgBox("The total amount of records read during this session =" & Counter)
    End Sub

    Dim CustNum As String
    Dim FirstName As String
    Dim LastName As String
    Dim CreditLimit As Short
    Dim CustomerSince As Short
    Dim PhoneNum As String
    Dim CustCity As String
    Dim CustState As String
    Private Sub btnCustomerListBox_click_Click(sender As Object, e As EventArgs) Handles btnCustomerListBox_click.Click
        FileOpen(1, "CustomerData.txt", OpenMode.Input)
        Do Until EOF(1)
            Input(1, CustNum)
            Input(1, FirstName)
            Input(1, LastName)
            Input(1, CreditLimit)
            Input(1, CustomerSince)
            Input(1, PhoneNum)
            Input(1, CustCity)
            Input(1, CustState)
            lbxCustomerForm.Items.Add(CustNum & vbTab & FirstName & vbTab & LastName & vbTab & CreditLimit & vbTab & CustomerSince & vbTab & PhoneNum & vbTab & CustCity & vbTab & CustState)

            Counter = Counter + 1
        Loop
        FileClose()
    End Sub

    Private Sub btnCustomerListVW_Click_Click(sender As Object, e As EventArgs) Handles btnCustomerListVW_Click.Click
        FileOpen(1, "CustomerData.txt", OpenMode.Input)
        Dim RowCounter As Short = 0
        Do Until EOF(1)
            Input(1, CustNum)
            Input(1, FirstName)
            Input(1, LastName)
            Input(1, CreditLimit)
            Input(1, CustomerSince)
            Input(1, PhoneNum)
            Input(1, CustCity)
            Input(1, CustState)
            lstvwCustomerData.Items.Add(CustNum)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(FirstName)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(LastName)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(CreditLimit)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(CustomerSince)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(PhoneNum)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(CustCity)
            lstvwCustomerData.Items(RowCounter).SubItems.Add(CustState)
            RowCounter = RowCounter + 1
            Counter = Counter + 1
        Loop
        FileClose()
    End Sub
End Class