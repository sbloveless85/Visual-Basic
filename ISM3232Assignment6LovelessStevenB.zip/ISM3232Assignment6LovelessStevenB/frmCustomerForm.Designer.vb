﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCustomerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCloseForm = New System.Windows.Forms.Button()
        Me.btnCLRLists = New System.Windows.Forms.Button()
        Me.btnCustomerRecords_Click = New System.Windows.Forms.Button()
        Me.lstvwCustomerData = New System.Windows.Forms.ListView()
        Me.chdCustNum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdFirstName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdLastName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdCreditLimit = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdCustSince = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdPhoneNum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdCustCity = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdCustState = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnCustomerListVW_Click = New System.Windows.Forms.Button()
        Me.btnCustomerListBox_click = New System.Windows.Forms.Button()
        Me.lbxCustomerForm = New System.Windows.Forms.ListView()
        Me.SuspendLayout()
        '
        'btnCloseForm
        '
        Me.btnCloseForm.Location = New System.Drawing.Point(433, 303)
        Me.btnCloseForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCloseForm.MinimumSize = New System.Drawing.Size(100, 32)
        Me.btnCloseForm.Name = "btnCloseForm"
        Me.btnCloseForm.Size = New System.Drawing.Size(103, 32)
        Me.btnCloseForm.TabIndex = 13
        Me.btnCloseForm.Text = "Close this form"
        Me.btnCloseForm.UseVisualStyleBackColor = True
        '
        'btnCLRLists
        '
        Me.btnCLRLists.Location = New System.Drawing.Point(297, 303)
        Me.btnCLRLists.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCLRLists.MinimumSize = New System.Drawing.Size(100, 32)
        Me.btnCLRLists.Name = "btnCLRLists"
        Me.btnCLRLists.Size = New System.Drawing.Size(103, 32)
        Me.btnCLRLists.TabIndex = 12
        Me.btnCLRLists.Text = "Clear Both Lists"
        Me.btnCLRLists.UseVisualStyleBackColor = True
        '
        'btnCustomerRecords_Click
        '
        Me.btnCustomerRecords_Click.Location = New System.Drawing.Point(109, 286)
        Me.btnCustomerRecords_Click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCustomerRecords_Click.MinimumSize = New System.Drawing.Size(153, 49)
        Me.btnCustomerRecords_Click.Name = "btnCustomerRecords_Click"
        Me.btnCustomerRecords_Click.Size = New System.Drawing.Size(155, 49)
        Me.btnCustomerRecords_Click.TabIndex = 11
        Me.btnCustomerRecords_Click.Text = "Display Number of Customer Records Read in this Session"
        Me.btnCustomerRecords_Click.UseVisualStyleBackColor = True
        '
        'lstvwCustomerData
        '
        Me.lstvwCustomerData.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chdCustNum, Me.chdFirstName, Me.chdLastName, Me.chdCreditLimit, Me.chdCustSince, Me.chdPhoneNum, Me.chdCustCity, Me.chdCustState})
        Me.lstvwCustomerData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstvwCustomerData.HideSelection = False
        Me.lstvwCustomerData.Location = New System.Drawing.Point(53, 200)
        Me.lstvwCustomerData.Margin = New System.Windows.Forms.Padding(1)
        Me.lstvwCustomerData.MinimumSize = New System.Drawing.Size(568, 73)
        Me.lstvwCustomerData.Name = "lstvwCustomerData"
        Me.lstvwCustomerData.Size = New System.Drawing.Size(568, 73)
        Me.lstvwCustomerData.TabIndex = 10
        Me.lstvwCustomerData.TileSize = New System.Drawing.Size(1, 1)
        Me.lstvwCustomerData.UseCompatibleStateImageBehavior = False
        Me.lstvwCustomerData.View = System.Windows.Forms.View.Details
        '
        'chdCustNum
        '
        Me.chdCustNum.Text = "Cust #"
        Me.chdCustNum.Width = 50
        '
        'chdFirstName
        '
        Me.chdFirstName.Text = "First Name"
        Me.chdFirstName.Width = 75
        '
        'chdLastName
        '
        Me.chdLastName.Text = "Last Name"
        Me.chdLastName.Width = 75
        '
        'chdCreditLimit
        '
        Me.chdCreditLimit.Text = "Credit Limit"
        Me.chdCreditLimit.Width = 75
        '
        'chdCustSince
        '
        Me.chdCustSince.Text = "Customer Since"
        Me.chdCustSince.Width = 100
        '
        'chdPhoneNum
        '
        Me.chdPhoneNum.Text = "Phone Number"
        Me.chdPhoneNum.Width = 95
        '
        'chdCustCity
        '
        Me.chdCustCity.Text = "City"
        Me.chdCustCity.Width = 50
        '
        'chdCustState
        '
        Me.chdCustState.Text = "State"
        Me.chdCustState.Width = 50
        '
        'btnCustomerListVW_Click
        '
        Me.btnCustomerListVW_Click.Location = New System.Drawing.Point(200, 152)
        Me.btnCustomerListVW_Click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCustomerListVW_Click.MinimumSize = New System.Drawing.Size(267, 26)
        Me.btnCustomerListVW_Click.Name = "btnCustomerListVW_Click"
        Me.btnCustomerListVW_Click.Size = New System.Drawing.Size(267, 27)
        Me.btnCustomerListVW_Click.TabIndex = 9
        Me.btnCustomerListVW_Click.Text = "Display Customer Data in the List View Below"
        Me.btnCustomerListVW_Click.UseVisualStyleBackColor = True
        '
        'btnCustomerListBox_click
        '
        Me.btnCustomerListBox_click.Location = New System.Drawing.Point(200, 18)
        Me.btnCustomerListBox_click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnCustomerListBox_click.MinimumSize = New System.Drawing.Size(267, 26)
        Me.btnCustomerListBox_click.Name = "btnCustomerListBox_click"
        Me.btnCustomerListBox_click.Size = New System.Drawing.Size(267, 27)
        Me.btnCustomerListBox_click.TabIndex = 8
        Me.btnCustomerListBox_click.Text = "Display Customer Data in the ListBox Below"
        Me.btnCustomerListBox_click.UseVisualStyleBackColor = True
        '
        'lbxCustomerForm
        '
        Me.lbxCustomerForm.AllowColumnReorder = True
        Me.lbxCustomerForm.HideSelection = False
        Me.lbxCustomerForm.Location = New System.Drawing.Point(53, 62)
        Me.lbxCustomerForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.lbxCustomerForm.MinimumSize = New System.Drawing.Size(568, 73)
        Me.lbxCustomerForm.Name = "lbxCustomerForm"
        Me.lbxCustomerForm.Size = New System.Drawing.Size(568, 73)
        Me.lbxCustomerForm.TabIndex = 7
        Me.lbxCustomerForm.UseCompatibleStateImageBehavior = False
        '
        'frmCustomerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(666, 365)
        Me.Controls.Add(Me.btnCloseForm)
        Me.Controls.Add(Me.btnCLRLists)
        Me.Controls.Add(Me.btnCustomerRecords_Click)
        Me.Controls.Add(Me.lstvwCustomerData)
        Me.Controls.Add(Me.btnCustomerListVW_Click)
        Me.Controls.Add(Me.btnCustomerListBox_click)
        Me.Controls.Add(Me.lbxCustomerForm)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MinimumSize = New System.Drawing.Size(682, 404)
        Me.Name = "frmCustomerForm"
        Me.Text = "Customer Data"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCloseForm As Button
    Friend WithEvents btnCLRLists As Button
    Friend WithEvents btnCustomerRecords_Click As Button
    Friend WithEvents lstvwCustomerData As ListView
    Friend WithEvents chdCustNum As ColumnHeader
    Friend WithEvents chdFirstName As ColumnHeader
    Friend WithEvents chdLastName As ColumnHeader
    Friend WithEvents chdCreditLimit As ColumnHeader
    Friend WithEvents btnCustomerListVW_Click As Button
    Friend WithEvents btnCustomerListBox_click As Button
    Friend WithEvents lbxCustomerForm As ListView
    Friend WithEvents chdCustSince As ColumnHeader
    Friend WithEvents chdPhoneNum As ColumnHeader
    Friend WithEvents chdCustCity As ColumnHeader
    Friend WithEvents chdCustState As ColumnHeader
End Class
