﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSupplierForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbxSupplierForm = New System.Windows.Forms.ListView()
        Me.btnSupplierListBox_click = New System.Windows.Forms.Button()
        Me.btnSupplierListVW_Click = New System.Windows.Forms.Button()
        Me.lstvwSupplierData = New System.Windows.Forms.ListView()
        Me.chdSupplierNum = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdSupplierName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdSupplierCity = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdSupplierState = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnDisplayRecordsRead = New System.Windows.Forms.Button()
        Me.btnClearSupplierLists_Click = New System.Windows.Forms.Button()
        Me.btnSupplierCloseForm = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbxSupplierForm
        '
        Me.lbxSupplierForm.HideSelection = False
        Me.lbxSupplierForm.Location = New System.Drawing.Point(51, 58)
        Me.lbxSupplierForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.lbxSupplierForm.MinimumSize = New System.Drawing.Size(428, 73)
        Me.lbxSupplierForm.Name = "lbxSupplierForm"
        Me.lbxSupplierForm.Size = New System.Drawing.Size(428, 73)
        Me.lbxSupplierForm.TabIndex = 0
        Me.lbxSupplierForm.UseCompatibleStateImageBehavior = False
        '
        'btnSupplierListBox_click
        '
        Me.btnSupplierListBox_click.Location = New System.Drawing.Point(143, 15)
        Me.btnSupplierListBox_click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSupplierListBox_click.MinimumSize = New System.Drawing.Size(267, 26)
        Me.btnSupplierListBox_click.Name = "btnSupplierListBox_click"
        Me.btnSupplierListBox_click.Size = New System.Drawing.Size(267, 27)
        Me.btnSupplierListBox_click.TabIndex = 1
        Me.btnSupplierListBox_click.Text = "Display Supplier Data in the ListBox Below"
        Me.btnSupplierListBox_click.UseVisualStyleBackColor = True
        '
        'btnSupplierListVW_Click
        '
        Me.btnSupplierListVW_Click.Location = New System.Drawing.Point(143, 149)
        Me.btnSupplierListVW_Click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSupplierListVW_Click.MinimumSize = New System.Drawing.Size(267, 26)
        Me.btnSupplierListVW_Click.Name = "btnSupplierListVW_Click"
        Me.btnSupplierListVW_Click.Size = New System.Drawing.Size(267, 27)
        Me.btnSupplierListVW_Click.TabIndex = 2
        Me.btnSupplierListVW_Click.Text = "Display Supplier Data in the List View Below"
        Me.btnSupplierListVW_Click.UseVisualStyleBackColor = True
        '
        'lstvwSupplierData
        '
        Me.lstvwSupplierData.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chdSupplierNum, Me.chdSupplierName, Me.chdSupplierCity, Me.chdSupplierState})
        Me.lstvwSupplierData.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstvwSupplierData.HideSelection = False
        Me.lstvwSupplierData.Location = New System.Drawing.Point(51, 196)
        Me.lstvwSupplierData.Margin = New System.Windows.Forms.Padding(1)
        Me.lstvwSupplierData.MinimumSize = New System.Drawing.Size(428, 73)
        Me.lstvwSupplierData.Name = "lstvwSupplierData"
        Me.lstvwSupplierData.Size = New System.Drawing.Size(428, 73)
        Me.lstvwSupplierData.TabIndex = 3
        Me.lstvwSupplierData.TileSize = New System.Drawing.Size(1, 1)
        Me.lstvwSupplierData.UseCompatibleStateImageBehavior = False
        Me.lstvwSupplierData.View = System.Windows.Forms.View.Details
        '
        'chdSupplierNum
        '
        Me.chdSupplierNum.Text = "Supplier Number"
        Me.chdSupplierNum.Width = 150
        '
        'chdSupplierName
        '
        Me.chdSupplierName.Text = "Supplier Name"
        Me.chdSupplierName.Width = 135
        '
        'chdSupplierCity
        '
        Me.chdSupplierCity.Text = "City"
        Me.chdSupplierCity.Width = 70
        '
        'chdSupplierState
        '
        Me.chdSupplierState.Text = "State"
        '
        'btnDisplayRecordsRead
        '
        Me.btnDisplayRecordsRead.Location = New System.Drawing.Point(51, 283)
        Me.btnDisplayRecordsRead.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnDisplayRecordsRead.MinimumSize = New System.Drawing.Size(153, 49)
        Me.btnDisplayRecordsRead.Name = "btnDisplayRecordsRead"
        Me.btnDisplayRecordsRead.Size = New System.Drawing.Size(155, 49)
        Me.btnDisplayRecordsRead.TabIndex = 4
        Me.btnDisplayRecordsRead.Text = "Display Number of Supplier Records Read in this Session"
        Me.btnDisplayRecordsRead.UseVisualStyleBackColor = True
        '
        'btnClearSupplierLists_Click
        '
        Me.btnClearSupplierLists_Click.Location = New System.Drawing.Point(240, 300)
        Me.btnClearSupplierLists_Click.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnClearSupplierLists_Click.MinimumSize = New System.Drawing.Size(100, 32)
        Me.btnClearSupplierLists_Click.Name = "btnClearSupplierLists_Click"
        Me.btnClearSupplierLists_Click.Size = New System.Drawing.Size(103, 32)
        Me.btnClearSupplierLists_Click.TabIndex = 5
        Me.btnClearSupplierLists_Click.Text = "Clear Both Lists"
        Me.btnClearSupplierLists_Click.UseVisualStyleBackColor = True
        '
        'btnSupplierCloseForm
        '
        Me.btnSupplierCloseForm.Location = New System.Drawing.Point(375, 300)
        Me.btnSupplierCloseForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnSupplierCloseForm.MinimumSize = New System.Drawing.Size(100, 32)
        Me.btnSupplierCloseForm.Name = "btnSupplierCloseForm"
        Me.btnSupplierCloseForm.Size = New System.Drawing.Size(103, 32)
        Me.btnSupplierCloseForm.TabIndex = 6
        Me.btnSupplierCloseForm.Text = "Close this form"
        Me.btnSupplierCloseForm.UseVisualStyleBackColor = True
        '
        'frmSupplierForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(533, 354)
        Me.Controls.Add(Me.btnSupplierCloseForm)
        Me.Controls.Add(Me.btnClearSupplierLists_Click)
        Me.Controls.Add(Me.btnDisplayRecordsRead)
        Me.Controls.Add(Me.lstvwSupplierData)
        Me.Controls.Add(Me.btnSupplierListVW_Click)
        Me.Controls.Add(Me.btnSupplierListBox_click)
        Me.Controls.Add(Me.lbxSupplierForm)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MinimumSize = New System.Drawing.Size(549, 391)
        Me.Name = "frmSupplierForm"
        Me.Text = "Supplier Data"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lbxSupplierForm As ListView
    Friend WithEvents btnSupplierListBox_click As Button
    Friend WithEvents btnSupplierListVW_Click As Button
    Friend WithEvents lstvwSupplierData As ListView
    Friend WithEvents chdSupplierNum As ColumnHeader
    Friend WithEvents chdSupplierName As ColumnHeader
    Friend WithEvents chdSupplierCity As ColumnHeader
    Friend WithEvents chdSupplierState As ColumnHeader
    Friend WithEvents btnDisplayRecordsRead As Button
    Friend WithEvents btnClearSupplierLists_Click As Button
    Friend WithEvents btnSupplierCloseForm As Button
End Class
