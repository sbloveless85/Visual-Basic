﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAssignment6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblassgn6 = New System.Windows.Forms.Label()
        Me.lbl2assign6 = New System.Windows.Forms.Label()
        Me.btnShowCustomerForm = New System.Windows.Forms.Button()
        Me.btnShowSupplierForm = New System.Windows.Forms.Button()
        Me.btnDisplayRecordsRead = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblassgn6
        '
        Me.lblassgn6.AutoSize = True
        Me.lblassgn6.Location = New System.Drawing.Point(104, 62)
        Me.lblassgn6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblassgn6.Name = "lblassgn6"
        Me.lblassgn6.Size = New System.Drawing.Size(119, 13)
        Me.lblassgn6.TabIndex = 0
        Me.lblassgn6.Text = "ISM3232, Assignment 6"
        '
        'lbl2assign6
        '
        Me.lbl2assign6.AutoSize = True
        Me.lbl2assign6.Location = New System.Drawing.Point(115, 84)
        Me.lbl2assign6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl2assign6.Name = "lbl2assign6"
        Me.lbl2assign6.Size = New System.Drawing.Size(101, 13)
        Me.lbl2assign6.TabIndex = 1
        Me.lbl2assign6.Text = "By Steven Loveless"
        '
        'btnShowCustomerForm
        '
        Me.btnShowCustomerForm.Location = New System.Drawing.Point(51, 123)
        Me.btnShowCustomerForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnShowCustomerForm.MinimumSize = New System.Drawing.Size(103, 39)
        Me.btnShowCustomerForm.Name = "btnShowCustomerForm"
        Me.btnShowCustomerForm.Size = New System.Drawing.Size(103, 39)
        Me.btnShowCustomerForm.TabIndex = 2
        Me.btnShowCustomerForm.Text = "Show Customer Form"
        Me.btnShowCustomerForm.UseVisualStyleBackColor = True
        '
        'btnShowSupplierForm
        '
        Me.btnShowSupplierForm.Location = New System.Drawing.Point(170, 123)
        Me.btnShowSupplierForm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnShowSupplierForm.MinimumSize = New System.Drawing.Size(103, 39)
        Me.btnShowSupplierForm.Name = "btnShowSupplierForm"
        Me.btnShowSupplierForm.Size = New System.Drawing.Size(103, 39)
        Me.btnShowSupplierForm.TabIndex = 3
        Me.btnShowSupplierForm.Text = "Show Supplier Form"
        Me.btnShowSupplierForm.UseVisualStyleBackColor = True
        '
        'btnDisplayRecordsRead
        '
        Me.btnDisplayRecordsRead.Location = New System.Drawing.Point(90, 183)
        Me.btnDisplayRecordsRead.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnDisplayRecordsRead.MinimumSize = New System.Drawing.Size(153, 45)
        Me.btnDisplayRecordsRead.Name = "btnDisplayRecordsRead"
        Me.btnDisplayRecordsRead.Size = New System.Drawing.Size(153, 45)
        Me.btnDisplayRecordsRead.TabIndex = 4
        Me.btnDisplayRecordsRead.Text = "Display Number of Records Read in this Session"
        Me.btnDisplayRecordsRead.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(125, 255)
        Me.Button4.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button4.MinimumSize = New System.Drawing.Size(73, 26)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(73, 26)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "Exit"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'frmAssignment6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(323, 365)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.btnDisplayRecordsRead)
        Me.Controls.Add(Me.btnShowSupplierForm)
        Me.Controls.Add(Me.btnShowCustomerForm)
        Me.Controls.Add(Me.lbl2assign6)
        Me.Controls.Add(Me.lblassgn6)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MinimumSize = New System.Drawing.Size(339, 404)
        Me.Name = "frmAssignment6"
        Me.Text = "ISM3232 Assignment 6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblassgn6 As Label
    Friend WithEvents lbl2assign6 As Label
    Friend WithEvents btnShowCustomerForm As Button
    Friend WithEvents btnShowSupplierForm As Button
    Friend WithEvents btnDisplayRecordsRead As Button
    Friend WithEvents Button4 As Button
End Class
