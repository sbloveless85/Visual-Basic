﻿Public Class frmAssignment6
    Public Count As Short
    Private Sub btnShowCustomerForm_Click(sender As Object, e As EventArgs) Handles btnShowCustomerForm.Click
        Dim oForm As New frmCustomerForm
        oForm.Show()
    End Sub

    Private Sub btnShowSupplierForm_Click(sender As Object, e As EventArgs) Handles btnShowSupplierForm.Click
        Dim oForm As New frmSupplierForm
        oForm.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        End
    End Sub

    Private Sub btnDisplayRecordsRead_Click(sender As Object, e As EventArgs) Handles btnDisplayRecordsRead.Click
        Count = frmCustomerForm.Counter + frmSupplierForm.SupCount
        MsgBox("The total amount of records read during this session = " & Count)
    End Sub
End Class
