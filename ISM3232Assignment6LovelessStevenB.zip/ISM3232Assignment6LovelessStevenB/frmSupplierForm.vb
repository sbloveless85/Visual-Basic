﻿Public Class frmSupplierForm
    Public SupCount As Short
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClearSupplierLists_Click.Click
        lstvwSupplierData.Items.Clear()
        lbxSupplierForm.Items.Clear()
    End Sub

    Private Sub btnSupplierCloseForm_Click(sender As Object, e As EventArgs) Handles btnSupplierCloseForm.Click
        Me.Close()
    End Sub

    Private Sub btnDisplayRecordsRead_Click(sender As Object, e As EventArgs) Handles btnDisplayRecordsRead.Click
        MsgBox("The total amount of records read during this session =" & SupCount)
    End Sub
    Dim SupplierNum As String
    Dim SupplierName As String
    Dim SupCity As String
    Dim SupState As String
    Private Sub btnSupplierListBox_click_Click(sender As Object, e As EventArgs) Handles btnSupplierListBox_click.Click
        FileOpen(1, "SupplierData.txt", OpenMode.Input)
        Do Until EOF(1)
            Input(1, SupplierNum)
            Input(1, SupplierName)
            Input(1, SupCity)
            Input(1, SupState)
            lbxSupplierForm.Items.Add(SupplierNum & vbTab & SupplierName & vbTab & SupCity & vbTab & SupState)
            SupCount = SupCount + 1
        Loop
        FileClose()
    End Sub

    Private Sub btnSupplierListVW_Click_Click(sender As Object, e As EventArgs) Handles btnSupplierListVW_Click.Click
        FileOpen(1, "SupplierData.txt", OpenMode.Input)
        Dim RowCounter As Short = 0
        Do Until EOF(1)
            Input(1, SupplierNum)
            Input(1, SupplierName)
            Input(1, SupCity)
            Input(1, SupState)
            lstvwSupplierData.Items.Add(SupplierNum)
            lstvwSupplierData.Items(RowCounter).SubItems.Add(SupplierName)
            lstvwSupplierData.Items(RowCounter).SubItems.Add(SupCity)
            lstvwSupplierData.Items(RowCounter).SubItems.Add(SupState)
            RowCounter = RowCounter + 1
            SupCount = SupCount + 1
        Loop
    End Sub
End Class