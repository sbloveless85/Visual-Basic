﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmA7LovelessStevenB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_depreciationschedcalc = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtOrigValAsset = New System.Windows.Forms.TextBox()
        Me.txtSalvageValAsset = New System.Windows.Forms.TextBox()
        Me.txtUsefulLifeAsset = New System.Windows.Forms.TextBox()
        Me.lbl_origValAsset = New System.Windows.Forms.Label()
        Me.lbl_SalvageValAsset = New System.Windows.Forms.Label()
        Me.lbl_usefullifeasset = New System.Windows.Forms.Label()
        Me.btn_computedepreciationsched = New System.Windows.Forms.Button()
        Me.lvwDeprecSched = New System.Windows.Forms.ListView()
        Me.chdYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdDepreciationExpense = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdAccumulatedDepreciation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chdBookValueatEndofYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'lbl_depreciationschedcalc
        '
        Me.lbl_depreciationschedcalc.AutoSize = True
        Me.lbl_depreciationschedcalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_depreciationschedcalc.Location = New System.Drawing.Point(238, 34)
        Me.lbl_depreciationschedcalc.Name = "lbl_depreciationschedcalc"
        Me.lbl_depreciationschedcalc.Size = New System.Drawing.Size(204, 13)
        Me.lbl_depreciationschedcalc.TabIndex = 0
        Me.lbl_depreciationschedcalc.Text = "Depcreciation Schedule Calculator"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(271, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(119, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "By Steven Loveless"
        '
        'txtOrigValAsset
        '
        Me.txtOrigValAsset.Location = New System.Drawing.Point(313, 124)
        Me.txtOrigValAsset.MinimumSize = New System.Drawing.Size(205, 20)
        Me.txtOrigValAsset.Name = "txtOrigValAsset"
        Me.txtOrigValAsset.Size = New System.Drawing.Size(206, 20)
        Me.txtOrigValAsset.TabIndex = 2
        '
        'txtSalvageValAsset
        '
        Me.txtSalvageValAsset.Location = New System.Drawing.Point(313, 182)
        Me.txtSalvageValAsset.MinimumSize = New System.Drawing.Size(205, 20)
        Me.txtSalvageValAsset.Name = "txtSalvageValAsset"
        Me.txtSalvageValAsset.Size = New System.Drawing.Size(206, 20)
        Me.txtSalvageValAsset.TabIndex = 3
        '
        'txtUsefulLifeAsset
        '
        Me.txtUsefulLifeAsset.Location = New System.Drawing.Point(313, 235)
        Me.txtUsefulLifeAsset.MinimumSize = New System.Drawing.Size(205, 20)
        Me.txtUsefulLifeAsset.Name = "txtUsefulLifeAsset"
        Me.txtUsefulLifeAsset.Size = New System.Drawing.Size(206, 20)
        Me.txtUsefulLifeAsset.TabIndex = 4
        '
        'lbl_origValAsset
        '
        Me.lbl_origValAsset.AutoSize = True
        Me.lbl_origValAsset.Location = New System.Drawing.Point(105, 131)
        Me.lbl_origValAsset.Name = "lbl_origValAsset"
        Me.lbl_origValAsset.Size = New System.Drawing.Size(113, 13)
        Me.lbl_origValAsset.TabIndex = 5
        Me.lbl_origValAsset.Text = "Original Value of Asset"
        '
        'lbl_SalvageValAsset
        '
        Me.lbl_SalvageValAsset.AutoSize = True
        Me.lbl_SalvageValAsset.Location = New System.Drawing.Point(105, 185)
        Me.lbl_SalvageValAsset.Name = "lbl_SalvageValAsset"
        Me.lbl_SalvageValAsset.Size = New System.Drawing.Size(117, 13)
        Me.lbl_SalvageValAsset.TabIndex = 6
        Me.lbl_SalvageValAsset.Text = "Salvage Value of Asset"
        '
        'lbl_usefullifeasset
        '
        Me.lbl_usefullifeasset.AutoSize = True
        Me.lbl_usefullifeasset.Location = New System.Drawing.Point(105, 242)
        Me.lbl_usefullifeasset.Name = "lbl_usefullifeasset"
        Me.lbl_usefullifeasset.Size = New System.Drawing.Size(94, 13)
        Me.lbl_usefullifeasset.TabIndex = 7
        Me.lbl_usefullifeasset.Text = "Useful life of Asset"
        '
        'btn_computedepreciationsched
        '
        Me.btn_computedepreciationsched.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_computedepreciationsched.Location = New System.Drawing.Point(136, 288)
        Me.btn_computedepreciationsched.MinimumSize = New System.Drawing.Size(385, 30)
        Me.btn_computedepreciationsched.Name = "btn_computedepreciationsched"
        Me.btn_computedepreciationsched.Size = New System.Drawing.Size(385, 30)
        Me.btn_computedepreciationsched.TabIndex = 8
        Me.btn_computedepreciationsched.Text = "Compute Depreciation Schedule"
        Me.btn_computedepreciationsched.UseVisualStyleBackColor = True
        '
        'lvwDeprecSched
        '
        Me.lvwDeprecSched.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chdYear, Me.chdDepreciationExpense, Me.chdAccumulatedDepreciation, Me.chdBookValueatEndofYear})
        Me.lvwDeprecSched.HideSelection = False
        Me.lvwDeprecSched.Location = New System.Drawing.Point(70, 355)
        Me.lvwDeprecSched.MinimumSize = New System.Drawing.Size(505, 110)
        Me.lvwDeprecSched.Name = "lvwDeprecSched"
        Me.lvwDeprecSched.Size = New System.Drawing.Size(506, 110)
        Me.lvwDeprecSched.TabIndex = 9
        Me.lvwDeprecSched.UseCompatibleStateImageBehavior = False
        Me.lvwDeprecSched.View = System.Windows.Forms.View.Details
        '
        'chdYear
        '
        Me.chdYear.Text = "Year"
        '
        'chdDepreciationExpense
        '
        Me.chdDepreciationExpense.Text = "Depreciation Expense"
        Me.chdDepreciationExpense.Width = 120
        '
        'chdAccumulatedDepreciation
        '
        Me.chdAccumulatedDepreciation.Text = "Accumulated Depreciation"
        Me.chdAccumulatedDepreciation.Width = 142
        '
        'chdBookValueatEndofYear
        '
        Me.chdBookValueatEndofYear.Text = "Book Val. at end of Year"
        Me.chdBookValueatEndofYear.Width = 186
        '
        'frmA7LovelessStevenB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(616, 516)
        Me.Controls.Add(Me.lvwDeprecSched)
        Me.Controls.Add(Me.btn_computedepreciationsched)
        Me.Controls.Add(Me.lbl_usefullifeasset)
        Me.Controls.Add(Me.lbl_SalvageValAsset)
        Me.Controls.Add(Me.lbl_origValAsset)
        Me.Controls.Add(Me.txtUsefulLifeAsset)
        Me.Controls.Add(Me.txtSalvageValAsset)
        Me.Controls.Add(Me.txtOrigValAsset)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbl_depreciationschedcalc)
        Me.MinimumSize = New System.Drawing.Size(630, 555)
        Me.Name = "frmA7LovelessStevenB"
        Me.Text = "ISM3232LovelessStevenB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_depreciationschedcalc As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtOrigValAsset As TextBox
    Friend WithEvents txtSalvageValAsset As TextBox
    Friend WithEvents txtUsefulLifeAsset As TextBox
    Friend WithEvents lbl_origValAsset As Label
    Friend WithEvents lbl_SalvageValAsset As Label
    Friend WithEvents lbl_usefullifeasset As Label
    Friend WithEvents btn_computedepreciationsched As Button
    Friend WithEvents lvwDeprecSched As ListView
    Friend WithEvents chdYear As ColumnHeader
    Friend WithEvents chdDepreciationExpense As ColumnHeader
    Friend WithEvents chdAccumulatedDepreciation As ColumnHeader
    Friend WithEvents chdBookValueatEndofYear As ColumnHeader
End Class
