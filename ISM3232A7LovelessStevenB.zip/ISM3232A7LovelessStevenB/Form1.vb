﻿Public Class frmA7LovelessStevenB

    Private Sub btn_computedepreciationsched_Click(sender As Object, e As EventArgs) Handles btn_computedepreciationsched.Click
        Try
            Dim OrigValAsset As Single
            Dim SalvageValAsset As Single
            Dim Usefullife As Short

            If txtOrigValAsset.Text = "" Then Throw New ApplicationException("Please enter a value for the original asset value")
            If txtSalvageValAsset.Text = "" Then Throw New ApplicationException("Please enter a value for the salvage value")
            If txtUsefulLifeAsset.Text = "" Then Throw New ApplicationException("Please enter a value for the useful life of the asset")

            If Not IsNumeric(txtOrigValAsset.Text) Then Throw New ApplicationException("Please enter a numeric value for the original asset value")
            If Not IsNumeric(txtSalvageValAsset.Text) Then Throw New ApplicationException("Please enter a numeric value for the salvage value")
            If Not IsNumeric(txtUsefulLifeAsset.Text) Then Throw New ApplicationException("Please enter a numeric value for the useful life of the asset")

            If txtOrigValAsset.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the original asset value")
            If txtSalvageValAsset.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the salvage value")
            If txtUsefulLifeAsset.Text < 0 Then Throw New ApplicationException("Please enter a positive value for the useful life of the asset")


            OrigValAsset = txtOrigValAsset.Text
            SalvageValAsset = txtSalvageValAsset.Text
            Usefullife = txtUsefulLifeAsset.Text

            Call ComputeDeprecSched(OrigValAsset, SalvageValAsset, Usefullife)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Sub ComputeDeprecSched(ByVal OrigValue As Single, ByVal SalvageValue As Single, ByVal UsefulLifeAsset As Short)

        Try
            Dim Counter As Short
            Dim RowCounter As Short
            Dim DepreciationExpense As Single
            Dim AccumulatedDeprec As Single
            Dim BookValEOY As Single
            Dim OriginalValue As Single
            Dim DeprecVal As Single

            OriginalValue = OrigValue
            DeprecVal = -Financial.SLN(OrigValue, SalvageValue, UsefulLifeAsset)

            lvwDeprecSched.Items.Clear()
            For Counter = 1 To UsefulLifeAsset
                DepreciationExpense = (OriginalValue - SalvageValue) / UsefulLifeAsset
                AccumulatedDeprec = DepreciationExpense * Counter
                BookValEOY = OriginalValue - AccumulatedDeprec
                lvwDeprecSched.Items.Add(Counter)
                lvwDeprecSched.Items(RowCounter).SubItems.Add(Format(DepreciationExpense, "currency"))
                lvwDeprecSched.Items(RowCounter).SubItems.Add(Format(AccumulatedDeprec, "currency"))
                lvwDeprecSched.Items(RowCounter).SubItems.Add(Format(BookValEOY, "currency"))
                RowCounter += 1
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class
