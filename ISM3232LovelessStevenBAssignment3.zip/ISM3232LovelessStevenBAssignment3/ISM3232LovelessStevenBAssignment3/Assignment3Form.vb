﻿Public Class Assignment3Form
    Private Sub btn_PrimeNumberArray_Click(sender As Object, e As EventArgs) Handles btn_PrimeNumberArray.Click
        Dim PrimeNumberArray() As Short
        Dim NumberOfArrays As Short = 6
        Dim Counter As Short
        ReDim PrimeNumberArray(NumberOfArrays)

        Counter = 1

        Do

            PrimeNumberArray(1) = 1
            PrimeNumberArray(2) = 2
            PrimeNumberArray(3) = 3
            PrimeNumberArray(4) = 5
            PrimeNumberArray(5) = 7
            PrimeNumberArray(6) = 11

            MsgBox(PrimeNumberArray(1))
            MsgBox(PrimeNumberArray(2))
            MsgBox(PrimeNumberArray(3))
            MsgBox(PrimeNumberArray(4))
            MsgBox(PrimeNumberArray(5))
            MsgBox(PrimeNumberArray(6))

            If Counter > 1 Then Exit Do
            Counter = Counter + 1
        Loop
        ReDim Preserve PrimeNumberArray(8)
        PrimeNumberArray(7) = 13
        PrimeNumberArray(8) = 17

        MsgBox(PrimeNumberArray(7))
        MsgBox(PrimeNumberArray(8))

    End Sub

    Private Sub btn_bmiandif_Click(sender As Object, e As EventArgs) Handles btn_bmiandif.Click
        Dim Weight As Single
        Dim Height As Single

        Weight = InputBox("Please enter your weight in Lbs.")
        Height = InputBox("Please enter your height in inches.")

        Dim BMI As Single
        BMI = Weight * 703 / (Height) ^ 2

        If (BMI > 30) Then
            MsgBox("You are obese. Your BMI is" & " " & BMI)
        ElseIf (BMI >= 25 And BMI < 29.9999) Then
            MsgBox("You are overweight. Your BMI is" & " " & BMI)
        ElseIf (BMI >= 18.5 And BMI < 24.9999) Then
            MsgBox("Your weight is normal. Your BMI is" & " " & BMI)
        ElseIf (BMI < 18.5) Then
            MsgBox("You are underweight. Your BMI is" & " " & BMI)

        End If
    End Sub

    Private Sub btn_bmiandselect_Click(sender As Object, e As EventArgs) Handles btn_bmiandselect.Click
        Dim Weight As Single
        Dim Height As Single

        Weight = InputBox("Please enter your weight in Lbs.")
        Height = InputBox("Please enter your height in inches.")

        Dim BMI As Single
        BMI = Weight * 703 / (Height) ^ 2

        Select Case BMI
            Case Is >= 30
                MsgBox("You are obese. Your BMI is" & " " & BMI)
            Case Is >= 25
                MsgBox("You are overweight. Your BMI is" & " " & BMI)
            Case Is >= 18.5
                MsgBox("Your weight is normal. Your BMI is" & " " & BMI)
            Case Is <= 18.5
                MsgBox("You are underweight. Your BMI is" & " " & BMI)

        End Select
    End Sub
End Class
