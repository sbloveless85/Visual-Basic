﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Assignment3Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_assignment = New System.Windows.Forms.Label()
        Me.btn_PrimeNumberArray = New System.Windows.Forms.Button()
        Me.btn_bmiandif = New System.Windows.Forms.Button()
        Me.btn_bmiandselect = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl_assignment
        '
        Me.lbl_assignment.AutoSize = True
        Me.lbl_assignment.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_assignment.Location = New System.Drawing.Point(246, 87)
        Me.lbl_assignment.Name = "lbl_assignment"
        Me.lbl_assignment.Size = New System.Drawing.Size(359, 20)
        Me.lbl_assignment.TabIndex = 0
        Me.lbl_assignment.Text = "ISM3232, Assignment 3 by Steven Loveless"
        '
        'btn_PrimeNumberArray
        '
        Me.btn_PrimeNumberArray.Location = New System.Drawing.Point(250, 143)
        Me.btn_PrimeNumberArray.Name = "btn_PrimeNumberArray"
        Me.btn_PrimeNumberArray.Size = New System.Drawing.Size(339, 69)
        Me.btn_PrimeNumberArray.TabIndex = 1
        Me.btn_PrimeNumberArray.Text = "Prime Number Array"
        Me.btn_PrimeNumberArray.UseVisualStyleBackColor = True
        '
        'btn_bmiandif
        '
        Me.btn_bmiandif.Location = New System.Drawing.Point(143, 269)
        Me.btn_bmiandif.Name = "btn_bmiandif"
        Me.btn_bmiandif.Size = New System.Drawing.Size(223, 78)
        Me.btn_bmiandif.TabIndex = 2
        Me.btn_bmiandif.Text = "BMI and IF Statement"
        Me.btn_bmiandif.UseVisualStyleBackColor = True
        '
        'btn_bmiandselect
        '
        Me.btn_bmiandselect.Location = New System.Drawing.Point(433, 269)
        Me.btn_bmiandselect.Name = "btn_bmiandselect"
        Me.btn_bmiandselect.Size = New System.Drawing.Size(223, 78)
        Me.btn_bmiandselect.TabIndex = 3
        Me.btn_bmiandselect.Text = "BMI and Select Statement"
        Me.btn_bmiandselect.UseVisualStyleBackColor = True
        '
        'Assignment3Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btn_bmiandselect)
        Me.Controls.Add(Me.btn_bmiandif)
        Me.Controls.Add(Me.btn_PrimeNumberArray)
        Me.Controls.Add(Me.lbl_assignment)
        Me.Name = "Assignment3Form"
        Me.Text = "ISM3232, Assignment 3, Steven Loveless"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_assignment As Label
    Friend WithEvents btn_PrimeNumberArray As Button
    Friend WithEvents btn_bmiandif As Button
    Friend WithEvents btn_bmiandselect As Button
End Class
