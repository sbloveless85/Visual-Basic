﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm2Instantiate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpbxInstantiate = New System.Windows.Forms.GroupBox()
        Me.lblAssetID = New System.Windows.Forms.Label()
        Me.lblAssetName = New System.Windows.Forms.Label()
        Me.txtbxAssetID = New System.Windows.Forms.TextBox()
        Me.txtbxAssetName = New System.Windows.Forms.TextBox()
        Me.lblUsefulLife = New System.Windows.Forms.Label()
        Me.lblSalvageVal = New System.Windows.Forms.Label()
        Me.lblOriginalVal = New System.Windows.Forms.Label()
        Me.btnClickInstantiate = New System.Windows.Forms.Button()
        Me.txtbxUsefulLife = New System.Windows.Forms.TextBox()
        Me.txtbxSalvageVal = New System.Windows.Forms.TextBox()
        Me.txtbxOriginalVal = New System.Windows.Forms.TextBox()
        Me.grpbxQuery = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblDeprecExpense = New System.Windows.Forms.Label()
        Me.lblyear = New System.Windows.Forms.Label()
        Me.txtbxYear = New System.Windows.Forms.TextBox()
        Me.btnClickQuerySLD = New System.Windows.Forms.Button()
        Me.txtbxBookValEOY = New System.Windows.Forms.TextBox()
        Me.txtbxAccumDeprec = New System.Windows.Forms.TextBox()
        Me.txtbxDeprecExpense = New System.Windows.Forms.TextBox()
        Me.btnQuitForm2 = New System.Windows.Forms.Button()
        Me.grpbxInstantiate.SuspendLayout()
        Me.grpbxQuery.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(140, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(386, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "First instantiate an asset object then query its depreciation"
        '
        'grpbxInstantiate
        '
        Me.grpbxInstantiate.Controls.Add(Me.lblAssetID)
        Me.grpbxInstantiate.Controls.Add(Me.lblAssetName)
        Me.grpbxInstantiate.Controls.Add(Me.txtbxAssetID)
        Me.grpbxInstantiate.Controls.Add(Me.txtbxAssetName)
        Me.grpbxInstantiate.Controls.Add(Me.lblUsefulLife)
        Me.grpbxInstantiate.Controls.Add(Me.lblSalvageVal)
        Me.grpbxInstantiate.Controls.Add(Me.lblOriginalVal)
        Me.grpbxInstantiate.Controls.Add(Me.btnClickInstantiate)
        Me.grpbxInstantiate.Controls.Add(Me.txtbxUsefulLife)
        Me.grpbxInstantiate.Controls.Add(Me.txtbxSalvageVal)
        Me.grpbxInstantiate.Controls.Add(Me.txtbxOriginalVal)
        Me.grpbxInstantiate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpbxInstantiate.Location = New System.Drawing.Point(31, 102)
        Me.grpbxInstantiate.MinimumSize = New System.Drawing.Size(216, 317)
        Me.grpbxInstantiate.Name = "grpbxInstantiate"
        Me.grpbxInstantiate.Size = New System.Drawing.Size(260, 317)
        Me.grpbxInstantiate.TabIndex = 1
        Me.grpbxInstantiate.TabStop = False
        Me.grpbxInstantiate.Text = "Instantiate"
        '
        'lblAssetID
        '
        Me.lblAssetID.AutoSize = True
        Me.lblAssetID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssetID.Location = New System.Drawing.Point(17, 55)
        Me.lblAssetID.Name = "lblAssetID"
        Me.lblAssetID.Size = New System.Drawing.Size(61, 16)
        Me.lblAssetID.TabIndex = 10
        Me.lblAssetID.Text = "Asset ID:"
        '
        'lblAssetName
        '
        Me.lblAssetName.AutoSize = True
        Me.lblAssetName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssetName.Location = New System.Drawing.Point(17, 89)
        Me.lblAssetName.Name = "lblAssetName"
        Me.lblAssetName.Size = New System.Drawing.Size(85, 16)
        Me.lblAssetName.TabIndex = 9
        Me.lblAssetName.Text = "Asset Name:"
        '
        'txtbxAssetID
        '
        Me.txtbxAssetID.Location = New System.Drawing.Point(140, 49)
        Me.txtbxAssetID.MinimumSize = New System.Drawing.Size(100, 22)
        Me.txtbxAssetID.Name = "txtbxAssetID"
        Me.txtbxAssetID.Size = New System.Drawing.Size(100, 22)
        Me.txtbxAssetID.TabIndex = 8
        '
        'txtbxAssetName
        '
        Me.txtbxAssetName.Location = New System.Drawing.Point(140, 83)
        Me.txtbxAssetName.MinimumSize = New System.Drawing.Size(100, 22)
        Me.txtbxAssetName.Name = "txtbxAssetName"
        Me.txtbxAssetName.Size = New System.Drawing.Size(100, 22)
        Me.txtbxAssetName.TabIndex = 7
        '
        'lblUsefulLife
        '
        Me.lblUsefulLife.AutoSize = True
        Me.lblUsefulLife.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsefulLife.Location = New System.Drawing.Point(17, 188)
        Me.lblUsefulLife.Name = "lblUsefulLife"
        Me.lblUsefulLife.Size = New System.Drawing.Size(73, 16)
        Me.lblUsefulLife.TabIndex = 6
        Me.lblUsefulLife.Text = "Useful Life:"
        '
        'lblSalvageVal
        '
        Me.lblSalvageVal.AutoSize = True
        Me.lblSalvageVal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalvageVal.Location = New System.Drawing.Point(17, 156)
        Me.lblSalvageVal.Name = "lblSalvageVal"
        Me.lblSalvageVal.Size = New System.Drawing.Size(100, 16)
        Me.lblSalvageVal.TabIndex = 5
        Me.lblSalvageVal.Text = "Salvage Value:"
        '
        'lblOriginalVal
        '
        Me.lblOriginalVal.AutoSize = True
        Me.lblOriginalVal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOriginalVal.Location = New System.Drawing.Point(17, 125)
        Me.lblOriginalVal.Name = "lblOriginalVal"
        Me.lblOriginalVal.Size = New System.Drawing.Size(95, 16)
        Me.lblOriginalVal.TabIndex = 4
        Me.lblOriginalVal.Text = "Original Value:"
        '
        'btnClickInstantiate
        '
        Me.btnClickInstantiate.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClickInstantiate.Location = New System.Drawing.Point(37, 233)
        Me.btnClickInstantiate.MinimumSize = New System.Drawing.Size(175, 35)
        Me.btnClickInstantiate.Name = "btnClickInstantiate"
        Me.btnClickInstantiate.Size = New System.Drawing.Size(176, 35)
        Me.btnClickInstantiate.TabIndex = 3
        Me.btnClickInstantiate.Text = "Instantiate"
        Me.btnClickInstantiate.UseVisualStyleBackColor = True
        '
        'txtbxUsefulLife
        '
        Me.txtbxUsefulLife.Location = New System.Drawing.Point(140, 182)
        Me.txtbxUsefulLife.MinimumSize = New System.Drawing.Size(100, 22)
        Me.txtbxUsefulLife.Name = "txtbxUsefulLife"
        Me.txtbxUsefulLife.Size = New System.Drawing.Size(100, 22)
        Me.txtbxUsefulLife.TabIndex = 2
        '
        'txtbxSalvageVal
        '
        Me.txtbxSalvageVal.Location = New System.Drawing.Point(140, 150)
        Me.txtbxSalvageVal.MinimumSize = New System.Drawing.Size(100, 22)
        Me.txtbxSalvageVal.Name = "txtbxSalvageVal"
        Me.txtbxSalvageVal.Size = New System.Drawing.Size(100, 22)
        Me.txtbxSalvageVal.TabIndex = 1
        '
        'txtbxOriginalVal
        '
        Me.txtbxOriginalVal.Location = New System.Drawing.Point(140, 119)
        Me.txtbxOriginalVal.MinimumSize = New System.Drawing.Size(100, 22)
        Me.txtbxOriginalVal.Name = "txtbxOriginalVal"
        Me.txtbxOriginalVal.Size = New System.Drawing.Size(100, 22)
        Me.txtbxOriginalVal.TabIndex = 0
        '
        'grpbxQuery
        '
        Me.grpbxQuery.Controls.Add(Me.Label8)
        Me.grpbxQuery.Controls.Add(Me.Label7)
        Me.grpbxQuery.Controls.Add(Me.lblDeprecExpense)
        Me.grpbxQuery.Controls.Add(Me.lblyear)
        Me.grpbxQuery.Controls.Add(Me.txtbxYear)
        Me.grpbxQuery.Controls.Add(Me.btnClickQuerySLD)
        Me.grpbxQuery.Controls.Add(Me.txtbxBookValEOY)
        Me.grpbxQuery.Controls.Add(Me.txtbxAccumDeprec)
        Me.grpbxQuery.Controls.Add(Me.txtbxDeprecExpense)
        Me.grpbxQuery.Location = New System.Drawing.Point(312, 102)
        Me.grpbxQuery.MinimumSize = New System.Drawing.Size(386, 317)
        Me.grpbxQuery.Name = "grpbxQuery"
        Me.grpbxQuery.Size = New System.Drawing.Size(386, 317)
        Me.grpbxQuery.TabIndex = 2
        Me.grpbxQuery.TabStop = False
        Me.grpbxQuery.Text = "Query"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(18, 249)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(166, 16)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Book Value At End of Year"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(18, 201)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(166, 16)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Accumulated Depreciation"
        '
        'lblDeprecExpense
        '
        Me.lblDeprecExpense.AutoSize = True
        Me.lblDeprecExpense.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeprecExpense.Location = New System.Drawing.Point(18, 156)
        Me.lblDeprecExpense.Name = "lblDeprecExpense"
        Me.lblDeprecExpense.Size = New System.Drawing.Size(212, 16)
        Me.lblDeprecExpense.TabIndex = 10
        Me.lblDeprecExpense.Text = "Depreciation Expense for the Year"
        '
        'lblyear
        '
        Me.lblyear.AutoSize = True
        Me.lblyear.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblyear.Location = New System.Drawing.Point(18, 43)
        Me.lblyear.Name = "lblyear"
        Me.lblyear.Size = New System.Drawing.Size(42, 18)
        Me.lblyear.TabIndex = 9
        Me.lblyear.Text = "Year:"
        '
        'txtbxYear
        '
        Me.txtbxYear.Location = New System.Drawing.Point(90, 43)
        Me.txtbxYear.MinimumSize = New System.Drawing.Size(94, 20)
        Me.txtbxYear.Name = "txtbxYear"
        Me.txtbxYear.Size = New System.Drawing.Size(94, 20)
        Me.txtbxYear.TabIndex = 8
        '
        'btnClickQuerySLD
        '
        Me.btnClickQuerySLD.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClickQuerySLD.Location = New System.Drawing.Point(21, 88)
        Me.btnClickQuerySLD.MinimumSize = New System.Drawing.Size(329, 45)
        Me.btnClickQuerySLD.Name = "btnClickQuerySLD"
        Me.btnClickQuerySLD.Size = New System.Drawing.Size(329, 45)
        Me.btnClickQuerySLD.TabIndex = 7
        Me.btnClickQuerySLD.Text = "Query Straight-Line Depreciation"
        Me.btnClickQuerySLD.UseVisualStyleBackColor = True
        '
        'txtbxBookValEOY
        '
        Me.txtbxBookValEOY.BackColor = System.Drawing.SystemColors.Control
        Me.txtbxBookValEOY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbxBookValEOY.Location = New System.Drawing.Point(250, 242)
        Me.txtbxBookValEOY.MinimumSize = New System.Drawing.Size(100, 20)
        Me.txtbxBookValEOY.Name = "txtbxBookValEOY"
        Me.txtbxBookValEOY.Size = New System.Drawing.Size(100, 20)
        Me.txtbxBookValEOY.TabIndex = 5
        '
        'txtbxAccumDeprec
        '
        Me.txtbxAccumDeprec.BackColor = System.Drawing.SystemColors.Control
        Me.txtbxAccumDeprec.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbxAccumDeprec.Location = New System.Drawing.Point(250, 194)
        Me.txtbxAccumDeprec.MinimumSize = New System.Drawing.Size(100, 20)
        Me.txtbxAccumDeprec.Name = "txtbxAccumDeprec"
        Me.txtbxAccumDeprec.Size = New System.Drawing.Size(100, 20)
        Me.txtbxAccumDeprec.TabIndex = 4
        '
        'txtbxDeprecExpense
        '
        Me.txtbxDeprecExpense.BackColor = System.Drawing.SystemColors.Control
        Me.txtbxDeprecExpense.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbxDeprecExpense.Location = New System.Drawing.Point(250, 151)
        Me.txtbxDeprecExpense.MinimumSize = New System.Drawing.Size(100, 20)
        Me.txtbxDeprecExpense.Name = "txtbxDeprecExpense"
        Me.txtbxDeprecExpense.Size = New System.Drawing.Size(100, 20)
        Me.txtbxDeprecExpense.TabIndex = 3
        '
        'btnQuitForm2
        '
        Me.btnQuitForm2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuitForm2.Location = New System.Drawing.Point(203, 436)
        Me.btnQuitForm2.MinimumSize = New System.Drawing.Size(200, 45)
        Me.btnQuitForm2.Name = "btnQuitForm2"
        Me.btnQuitForm2.Size = New System.Drawing.Size(207, 45)
        Me.btnQuitForm2.TabIndex = 3
        Me.btnQuitForm2.Text = "Quit"
        Me.btnQuitForm2.UseVisualStyleBackColor = True
        '
        'frm2Instantiate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(728, 509)
        Me.Controls.Add(Me.btnQuitForm2)
        Me.Controls.Add(Me.grpbxQuery)
        Me.Controls.Add(Me.grpbxInstantiate)
        Me.Controls.Add(Me.Label1)
        Me.MinimumSize = New System.Drawing.Size(744, 548)
        Me.Name = "frm2Instantiate"
        Me.Text = "Instantiate Asset Object and Compute Depreciation"
        Me.grpbxInstantiate.ResumeLayout(False)
        Me.grpbxInstantiate.PerformLayout()
        Me.grpbxQuery.ResumeLayout(False)
        Me.grpbxQuery.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents grpbxInstantiate As GroupBox
    Friend WithEvents btnClickInstantiate As Button
    Friend WithEvents txtbxUsefulLife As TextBox
    Friend WithEvents txtbxSalvageVal As TextBox
    Friend WithEvents txtbxOriginalVal As TextBox
    Friend WithEvents grpbxQuery As GroupBox
    Friend WithEvents txtbxBookValEOY As TextBox
    Friend WithEvents txtbxAccumDeprec As TextBox
    Friend WithEvents txtbxDeprecExpense As TextBox
    Friend WithEvents btnQuitForm2 As Button
    Friend WithEvents txtbxYear As TextBox
    Friend WithEvents btnClickQuerySLD As Button
    Friend WithEvents lblUsefulLife As Label
    Friend WithEvents lblSalvageVal As Label
    Friend WithEvents lblOriginalVal As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblDeprecExpense As Label
    Friend WithEvents lblyear As Label
    Friend WithEvents lblAssetID As Label
    Friend WithEvents lblAssetName As Label
    Friend WithEvents txtbxAssetID As TextBox
    Friend WithEvents txtbxAssetName As TextBox
End Class
