﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmISM33232A8LovelessStevenB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAssignTtl = New System.Windows.Forms.Label()
        Me.lblAssgnTitleBy = New System.Windows.Forms.Label()
        Me.lbldirecttions = New System.Windows.Forms.Label()
        Me.lbldirections2 = New System.Windows.Forms.Label()
        Me.btnClickHereToBegin = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblAssignTtl
        '
        Me.lblAssignTtl.AutoSize = True
        Me.lblAssignTtl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssignTtl.Location = New System.Drawing.Point(149, 64)
        Me.lblAssignTtl.Name = "lblAssignTtl"
        Me.lblAssignTtl.Size = New System.Drawing.Size(200, 20)
        Me.lblAssignTtl.TabIndex = 0
        Me.lblAssignTtl.Text = "ISM3232, Assignment 8"
        '
        'lblAssgnTitleBy
        '
        Me.lblAssgnTitleBy.AutoSize = True
        Me.lblAssgnTitleBy.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssgnTitleBy.Location = New System.Drawing.Point(177, 103)
        Me.lblAssgnTitleBy.Name = "lblAssgnTitleBy"
        Me.lblAssgnTitleBy.Size = New System.Drawing.Size(137, 18)
        Me.lblAssgnTitleBy.TabIndex = 1
        Me.lblAssgnTitleBy.Text = "By Steven Loveless"
        '
        'lbldirecttions
        '
        Me.lbldirecttions.AutoSize = True
        Me.lbldirecttions.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldirecttions.Location = New System.Drawing.Point(60, 160)
        Me.lbldirecttions.Name = "lbldirecttions"
        Me.lbldirecttions.Size = New System.Drawing.Size(377, 18)
        Me.lbldirecttions.TabIndex = 2
        Me.lbldirecttions.Text = "In this application, you can instantiate new asset objects "
        '
        'lbldirections2
        '
        Me.lbldirections2.AutoSize = True
        Me.lbldirections2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldirections2.Location = New System.Drawing.Point(140, 198)
        Me.lbldirections2.Name = "lbldirections2"
        Me.lbldirections2.Size = New System.Drawing.Size(210, 18)
        Me.lbldirections2.TabIndex = 3
        Me.lbldirections2.Text = "and compute their depreciation"
        '
        'btnClickHereToBegin
        '
        Me.btnClickHereToBegin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClickHereToBegin.Location = New System.Drawing.Point(143, 254)
        Me.btnClickHereToBegin.MinimumSize = New System.Drawing.Size(210, 40)
        Me.btnClickHereToBegin.Name = "btnClickHereToBegin"
        Me.btnClickHereToBegin.Size = New System.Drawing.Size(210, 40)
        Me.btnClickHereToBegin.TabIndex = 4
        Me.btnClickHereToBegin.Text = "Click here to begin"
        Me.btnClickHereToBegin.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(203, 315)
        Me.btnQuit.MinimumSize = New System.Drawing.Size(100, 40)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(100, 40)
        Me.btnQuit.TabIndex = 5
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'frmISM33232A8LovelessStevenB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 401)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnClickHereToBegin)
        Me.Controls.Add(Me.lbldirections2)
        Me.Controls.Add(Me.lbldirecttions)
        Me.Controls.Add(Me.lblAssgnTitleBy)
        Me.Controls.Add(Me.lblAssignTtl)
        Me.MinimumSize = New System.Drawing.Size(500, 440)
        Me.Name = "frmISM33232A8LovelessStevenB"
        Me.Text = "ISM3232, Assignment 8 by Steven Loveless"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAssignTtl As Label
    Friend WithEvents lblAssgnTitleBy As Label
    Friend WithEvents lbldirecttions As Label
    Friend WithEvents lbldirections2 As Label
    Friend WithEvents btnClickHereToBegin As Button
    Friend WithEvents btnQuit As Button
End Class
