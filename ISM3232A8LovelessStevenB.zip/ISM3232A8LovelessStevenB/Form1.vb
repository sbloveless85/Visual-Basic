﻿Public Class frmISM33232A8LovelessStevenB
    Private Sub btnClickHereToBegin_Click(sender As Object, e As EventArgs) Handles btnClickHereToBegin.Click
        Dim oForm As New frm2Instantiate
        oForm.Show()
    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        End
    End Sub
End Class
