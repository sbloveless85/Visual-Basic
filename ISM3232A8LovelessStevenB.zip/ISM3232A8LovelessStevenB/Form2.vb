﻿Public Class frm2Instantiate

    Dim DeprecObject As New DeprecCalc
    Private Sub btnClickInstantiate_Click(sender As Object, e As EventArgs) Handles btnClickInstantiate.Click
        Try
            If txtbxAssetID.Text = "" Then Throw New ApplicationException("Please enter the Asset ID")
            If Not IsNumeric(txtbxAssetID.Text) Then Throw New ApplicationException("The Asset ID should be numeric")
            If CSng(txtbxAssetID.Text) < 0 Then Throw New ApplicationException("The Asset ID should be positive")

            If txtbxAssetName.Text = "" Then Throw New ApplicationException("Please enter the Asset Name")

            If txtbxOriginalVal.Text = "" Then Throw New ApplicationException("Please enter the Original Value for the asset")
            If Not IsNumeric(txtbxOriginalVal.Text) Then Throw New ApplicationException("The Original Value should be numeric")
            If CSng(txtbxOriginalVal.Text) < 0 Then Throw New ApplicationException("The Original Value should be positive")

            If txtbxSalvageVal.Text = "" Then Throw New ApplicationException("Please enter the Salvage Value for the asset")
            If Not IsNumeric(txtbxSalvageVal.Text) Then Throw New ApplicationException("The Salvage Value should be numeric")
            If CSng(txtbxSalvageVal.Text) < 0 Then Throw New ApplicationException("The Salvage Value should be positive")

            If txtbxUsefulLife.Text = "" Then Throw New ApplicationException("Please enter the Useful Life for the asset")
            If Not IsNumeric(txtbxUsefulLife.Text) Then Throw New ApplicationException("The Useful Life should be numeric")
            If CSng(txtbxUsefulLife.Text) < 0 Then Throw New ApplicationException("The Salvage Value should be positive")

            DeprecObject.OriginalValue = txtbxOriginalVal.Text
            DeprecObject.SalvageValue = txtbxSalvageVal.Text
            DeprecObject.UsefulLife = txtbxUsefulLife.Text


            MsgBox("The asset object has been instantiated.  You may now perform the depreciation query")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub btnClickQuerySLD_Click(sender As Object, e As EventArgs) Handles btnClickQuerySLD.Click
        Try
            If DeprecObject.OriginalValue = 0 Then Throw New ApplicationException("You must first instantiate an asset object")
            If txtbxYear.Text = "" Then Throw New ApplicationException("Please enter a year value")
            If Not IsNumeric(txtbxYear.Text) Then Throw New ApplicationException("The year value must be numeric")
            If CSng(txtbxYear.Text) < 0 Then Throw New ApplicationException("The year value must be positive")
            If CSng(txtbxYear.Text) > DeprecObject.UsefulLife Then Throw New ApplicationException("The year value should be less than or equal to the Useful Life, which is " & DeprecObject.UsefulLife)

            Dim Year As Short = txtbxYear.Text
            Dim DeprecExpense As Single
            Dim AccumDeprec As Single
            Dim BookValEOY As Single

            Call DeprecObject.DeprecCalculation(Year, DeprecExpense, AccumDeprec, BookValEOY)
            txtbxDeprecExpense.Text = Format(DeprecExpense, "Currency")
            txtbxAccumDeprec.Text = Format(AccumDeprec, "Currency")
            txtbxBookValEOY.Text = Format(BookValEOY, "Currency")


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnQuitForm2_Click(sender As Object, e As EventArgs) Handles btnQuitForm2.Click
        End
    End Sub
End Class