﻿Public Class DeprecCalc
    Dim mOriginalValue As Single
    Dim mSalvageValue As Single
    Dim mUsefulLife As Short

    Property OriginalValue As Single
        Get
            Return mOriginalValue
        End Get
        Set(ByVal value As Single)
            mOriginalValue = value
        End Set
    End Property

    Property SalvageValue As Single
        Get
            Return mSalvageValue
        End Get
        Set(ByVal value As Single)
            mSalvageValue = value
        End Set
    End Property

    Property UsefulLife As Short
        Get
            Return mUsefulLife
        End Get
        Set(ByVal value As Short)
            mUsefulLife = value
        End Set
    End Property

    Sub DeprecCalculation(ByVal Year As Integer, ByRef DepreciationExpense As Single, ByRef AccumulatedDeprec As Single, ByRef BookValueEOY As Single)
        DepreciationExpense = (mOriginalValue - mSalvageValue) / mUsefulLife
        AccumulatedDeprec = DepreciationExpense * Year
        BookValueEOY = mOriginalValue - AccumulatedDeprec
    End Sub
End Class
