﻿Public Class frmDepreciation
    Private Sub lblDepreciationExpense_Click(sender As Object, e As EventArgs) Handles lblDepreciationExpense.Click lblDepreciationExpense.SpecialEffect = 1

    End Sub
End Class
