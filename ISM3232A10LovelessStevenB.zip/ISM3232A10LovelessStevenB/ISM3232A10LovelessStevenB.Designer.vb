﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDepreciation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAssignment10SBL = New System.Windows.Forms.Label()
        Me.txtbxOrigVal = New System.Windows.Forms.TextBox()
        Me.lblOriginalValue = New System.Windows.Forms.Label()
        Me.txtbxSalvageVal = New System.Windows.Forms.TextBox()
        Me.txtbxUsefulLife = New System.Windows.Forms.TextBox()
        Me.lblSalvageValue = New System.Windows.Forms.Label()
        Me.lblUsefulLife = New System.Windows.Forms.Label()
        Me.lblDeprecExp = New System.Windows.Forms.Label()
        Me.btn_ClickComputeStrghtLnDeprec = New System.Windows.Forms.Button()
        Me.lblDepreciationExpense = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblAssignment10SBL
        '
        Me.lblAssignment10SBL.AutoSize = True
        Me.lblAssignment10SBL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssignment10SBL.Location = New System.Drawing.Point(94, 85)
        Me.lblAssignment10SBL.Name = "lblAssignment10SBL"
        Me.lblAssignment10SBL.Size = New System.Drawing.Size(287, 20)
        Me.lblAssignment10SBL.TabIndex = 0
        Me.lblAssignment10SBL.Text = "Assignment 10 by Steven Loveless"
        '
        'txtbxOrigVal
        '
        Me.txtbxOrigVal.Location = New System.Drawing.Point(247, 151)
        Me.txtbxOrigVal.MinimumSize = New System.Drawing.Size(161, 20)
        Me.txtbxOrigVal.Name = "txtbxOrigVal"
        Me.txtbxOrigVal.Size = New System.Drawing.Size(161, 20)
        Me.txtbxOrigVal.TabIndex = 1
        '
        'lblOriginalValue
        '
        Me.lblOriginalValue.AutoSize = True
        Me.lblOriginalValue.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOriginalValue.Location = New System.Drawing.Point(54, 149)
        Me.lblOriginalValue.Name = "lblOriginalValue"
        Me.lblOriginalValue.Size = New System.Drawing.Size(111, 20)
        Me.lblOriginalValue.TabIndex = 5
        Me.lblOriginalValue.Text = "Original Value:"
        '
        'txtbxSalvageVal
        '
        Me.txtbxSalvageVal.Location = New System.Drawing.Point(247, 206)
        Me.txtbxSalvageVal.MinimumSize = New System.Drawing.Size(161, 20)
        Me.txtbxSalvageVal.Name = "txtbxSalvageVal"
        Me.txtbxSalvageVal.Size = New System.Drawing.Size(161, 20)
        Me.txtbxSalvageVal.TabIndex = 9
        '
        'txtbxUsefulLife
        '
        Me.txtbxUsefulLife.Location = New System.Drawing.Point(247, 257)
        Me.txtbxUsefulLife.MinimumSize = New System.Drawing.Size(161, 20)
        Me.txtbxUsefulLife.Name = "txtbxUsefulLife"
        Me.txtbxUsefulLife.Size = New System.Drawing.Size(161, 20)
        Me.txtbxUsefulLife.TabIndex = 10
        '
        'lblSalvageValue
        '
        Me.lblSalvageValue.AutoSize = True
        Me.lblSalvageValue.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSalvageValue.Location = New System.Drawing.Point(54, 206)
        Me.lblSalvageValue.Name = "lblSalvageValue"
        Me.lblSalvageValue.Size = New System.Drawing.Size(115, 20)
        Me.lblSalvageValue.TabIndex = 12
        Me.lblSalvageValue.Text = "Salvage Value:"
        '
        'lblUsefulLife
        '
        Me.lblUsefulLife.AutoSize = True
        Me.lblUsefulLife.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsefulLife.Location = New System.Drawing.Point(54, 257)
        Me.lblUsefulLife.Name = "lblUsefulLife"
        Me.lblUsefulLife.Size = New System.Drawing.Size(127, 20)
        Me.lblUsefulLife.TabIndex = 13
        Me.lblUsefulLife.Text = "Useful Life (Yrs):"
        '
        'lblDeprecExp
        '
        Me.lblDeprecExp.AutoSize = True
        Me.lblDeprecExp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeprecExp.Location = New System.Drawing.Point(54, 310)
        Me.lblDeprecExp.Name = "lblDeprecExp"
        Me.lblDeprecExp.Size = New System.Drawing.Size(172, 20)
        Me.lblDeprecExp.TabIndex = 14
        Me.lblDeprecExp.Text = "Depreciation Exp (Yrs):"
        '
        'btn_ClickComputeStrghtLnDeprec
        '
        Me.btn_ClickComputeStrghtLnDeprec.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ClickComputeStrghtLnDeprec.Location = New System.Drawing.Point(79, 374)
        Me.btn_ClickComputeStrghtLnDeprec.MinimumSize = New System.Drawing.Size(300, 60)
        Me.btn_ClickComputeStrghtLnDeprec.Name = "btn_ClickComputeStrghtLnDeprec"
        Me.btn_ClickComputeStrghtLnDeprec.Size = New System.Drawing.Size(302, 60)
        Me.btn_ClickComputeStrghtLnDeprec.TabIndex = 15
        Me.btn_ClickComputeStrghtLnDeprec.Text = "Compute Straight Line Depreciation"
        Me.btn_ClickComputeStrghtLnDeprec.UseVisualStyleBackColor = True
        '
        'lblDepreciationExpense
        '
        Me.lblDepreciationExpense.AutoSize = True
        Me.lblDepreciationExpense.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDepreciationExpense.Location = New System.Drawing.Point(247, 313)
        Me.lblDepreciationExpense.MinimumSize = New System.Drawing.Size(161, 20)
        Me.lblDepreciationExpense.Name = "lblDepreciationExpense"
        Me.lblDepreciationExpense.Size = New System.Drawing.Size(161, 20)
        Me.lblDepreciationExpense.TabIndex = 16
        '
        'frmDepreciation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(475, 521)
        Me.Controls.Add(Me.lblDepreciationExpense)
        Me.Controls.Add(Me.btn_ClickComputeStrghtLnDeprec)
        Me.Controls.Add(Me.lblDeprecExp)
        Me.Controls.Add(Me.lblUsefulLife)
        Me.Controls.Add(Me.lblSalvageValue)
        Me.Controls.Add(Me.txtbxUsefulLife)
        Me.Controls.Add(Me.txtbxSalvageVal)
        Me.Controls.Add(Me.lblOriginalValue)
        Me.Controls.Add(Me.txtbxOrigVal)
        Me.Controls.Add(Me.lblAssignment10SBL)
        Me.MinimumSize = New System.Drawing.Size(491, 560)
        Me.Name = "frmDepreciation"
        Me.Text = "ISM3232A10 By Steven B Loveless"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAssignment10SBL As Label
    Friend WithEvents txtbxOrigVal As TextBox
    Friend WithEvents lblOriginalValue As Label
    Friend WithEvents txtbxSalvageVal As TextBox
    Friend WithEvents txtbxUsefulLife As TextBox
    Friend WithEvents lblSalvageValue As Label
    Friend WithEvents lblUsefulLife As Label
    Friend WithEvents lblDeprecExp As Label
    Friend WithEvents btn_ClickComputeStrghtLnDeprec As Button
    Friend WithEvents lblDepreciationExpense As Label
End Class
