﻿Public Class ISM3232Assignment5LovelessStevenB
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BTNComputeGrades_Click(sender As Object, e As EventArgs) Handles BTNComputeGrades.Click
        Dim LastName As String
        LastName = ""
        Dim FirstName As String
        FirstName = ""
        Dim Grades As Decimal
        Dim Grades2 As Decimal
        Dim Grades3 As Decimal
        Dim Grades4 As Decimal
        Dim Grades5 As Decimal
        Dim Grades6 As Decimal
        Dim Grades7 As Decimal

        FileOpen(1, "StudentScores.txt", OpenMode.Input)

        Do Until EOF(1)
            Input(1, LastName)
            Input(1, FirstName)
            Input(1, Grades)
            Input(1, Grades2)
            Input(1, Grades3)
            Input(1, Grades4)
            Input(1, Grades5)
            Input(1, Grades6)
            Input(1, Grades7)

            Dim TotalScore As Decimal
            TotalScore = (Grades + Grades2 + Grades3 + Grades4 + Grades5 + Grades6 + Grades7)

            Dim AvgGrade As Decimal
            AvgGrade = (((TotalScore) / 135) * 100)

            Dim LetterGrade As String
            LetterGrade = ""


            If AvgGrade >= 90 Then
                MsgBox("Grade for" & " " & LastName & "," & FirstName & " " & "is" & " " & "A" & ".")
                LetterGrade = "A"
            ElseIf (AvgGrade <= 89.9 And AvgGrade >= 80) Then
                MsgBox("Grade for" & " " & LastName & "," & FirstName & " " & "is" & " " & "B" & ".")
                LetterGrade = "B"
            ElseIf (AvgGrade <= 79.9 And AvgGrade >= 70) Then
                MsgBox("Grade for" & " " & LastName & "," & FirstName & " " & "is" & " " & "C" & ".")
                LetterGrade = "C"
            ElseIf (AvgGrade <= 69.9 And AvgGrade >= 60) Then
                MsgBox("Grade for" & " " & LastName & "," & FirstName & " " & "is" & " " & "D" & ".")
                LetterGrade = "D"
            ElseIf (AvgGrade < 60) Then
                MsgBox("Grade for" & " " & LastName & "," & FirstName & " " & "is" & " " & "F" & ".")
                LetterGrade = "F"
            End If


            If Not IO.File.Exists("Assign5StudentReport.txt") Then
                FileOpen(2, "Assign5StudentReport.txt", OpenMode.Output)
                Print(2, LastName, FirstName, TotalScore, AvgGrade, LetterGrade & vbCrLf)
                FileClose(2)
                MsgBox("New record created; please check the assignment debug folder.")
            ElseIf IO.File.Exists("Assign5StudentReport.txt") Then
                FileOpen(2, "Assign5StudentReport.txt", OpenMode.Append)
                Print(2, LastName, FirstName, TotalScore, AvgGrade, LetterGrade & vbCrLf)
                FileClose(2)
            End If
        Loop
        FileClose(1)
    End Sub
End Class
