﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ISM3232Assignment5LovelessStevenB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAssignbmentbyme = New System.Windows.Forms.Label()
        Me.BTNComputeGrades = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblAssignbmentbyme
        '
        Me.lblAssignbmentbyme.AutoSize = True
        Me.lblAssignbmentbyme.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAssignbmentbyme.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.lblAssignbmentbyme.Location = New System.Drawing.Point(66, 115)
        Me.lblAssignbmentbyme.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblAssignbmentbyme.Name = "lblAssignbmentbyme"
        Me.lblAssignbmentbyme.Size = New System.Drawing.Size(347, 18)
        Me.lblAssignbmentbyme.TabIndex = 0
        Me.lblAssignbmentbyme.Text = "ISM3232 Assignment 5 By Steven B Loveless"
        '
        'BTNComputeGrades
        '
        Me.BTNComputeGrades.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNComputeGrades.Location = New System.Drawing.Point(75, 173)
        Me.BTNComputeGrades.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BTNComputeGrades.MinimumSize = New System.Drawing.Size(338, 169)
        Me.BTNComputeGrades.Name = "BTNComputeGrades"
        Me.BTNComputeGrades.Size = New System.Drawing.Size(338, 169)
        Me.BTNComputeGrades.TabIndex = 1
        Me.BTNComputeGrades.Text = "Compute Grades"
        Me.BTNComputeGrades.UseVisualStyleBackColor = True
        '
        'ISM3232Assignment5LovelessStevenB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.BTNComputeGrades)
        Me.Controls.Add(Me.lblAssignbmentbyme)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MinimumSize = New System.Drawing.Size(500, 500)
        Me.Name = "ISM3232Assignment5LovelessStevenB"
        Me.Text = "ISM3232Assignment5LovelessStevenB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAssignbmentbyme As Label
    Friend WithEvents BTNComputeGrades As Button
End Class
