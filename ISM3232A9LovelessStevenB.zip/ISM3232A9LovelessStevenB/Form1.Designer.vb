﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmISM3232A9LovelessStevenB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblISMDesc = New System.Windows.Forms.Label()
        Me.lblISM3232_2 = New System.Windows.Forms.Label()
        Me.btnCLICKInheritance = New System.Windows.Forms.Button()
        Me.btnCLICKBalUsingPolyMorph = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblISMDesc
        '
        Me.lblISMDesc.AutoSize = True
        Me.lblISMDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblISMDesc.Location = New System.Drawing.Point(134, 51)
        Me.lblISMDesc.Name = "lblISMDesc"
        Me.lblISMDesc.Size = New System.Drawing.Size(227, 24)
        Me.lblISMDesc.TabIndex = 0
        Me.lblISMDesc.Text = "ISM3232 Assignment 9 "
        '
        'lblISM3232_2
        '
        Me.lblISM3232_2.AutoSize = True
        Me.lblISM3232_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblISM3232_2.Location = New System.Drawing.Point(177, 99)
        Me.lblISM3232_2.Name = "lblISM3232_2"
        Me.lblISM3232_2.Size = New System.Drawing.Size(142, 16)
        Me.lblISM3232_2.TabIndex = 1
        Me.lblISM3232_2.Text = "By Steven B. Loveless"
        '
        'btnCLICKInheritance
        '
        Me.btnCLICKInheritance.Location = New System.Drawing.Point(61, 170)
        Me.btnCLICKInheritance.MinimumSize = New System.Drawing.Size(159, 75)
        Me.btnCLICKInheritance.Name = "btnCLICKInheritance"
        Me.btnCLICKInheritance.Size = New System.Drawing.Size(159, 75)
        Me.btnCLICKInheritance.TabIndex = 2
        Me.btnCLICKInheritance.Text = "Account Balances Using Inheritance"
        Me.btnCLICKInheritance.UseVisualStyleBackColor = True
        '
        'btnCLICKBalUsingPolyMorph
        '
        Me.btnCLICKBalUsingPolyMorph.Location = New System.Drawing.Point(286, 170)
        Me.btnCLICKBalUsingPolyMorph.MinimumSize = New System.Drawing.Size(159, 75)
        Me.btnCLICKBalUsingPolyMorph.Name = "btnCLICKBalUsingPolyMorph"
        Me.btnCLICKBalUsingPolyMorph.Size = New System.Drawing.Size(159, 75)
        Me.btnCLICKBalUsingPolyMorph.TabIndex = 3
        Me.btnCLICKBalUsingPolyMorph.Text = "Account Balances Using Polymorphism"
        Me.btnCLICKBalUsingPolyMorph.UseVisualStyleBackColor = True
        '
        'frmISM3232A9LovelessStevenB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 312)
        Me.Controls.Add(Me.btnCLICKBalUsingPolyMorph)
        Me.Controls.Add(Me.btnCLICKInheritance)
        Me.Controls.Add(Me.lblISM3232_2)
        Me.Controls.Add(Me.lblISMDesc)
        Me.MinimumSize = New System.Drawing.Size(515, 350)
        Me.Name = "frmISM3232A9LovelessStevenB"
        Me.Text = "ISM3232 A9 LovelessStevenB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblISMDesc As Label
    Friend WithEvents lblISM3232_2 As Label
    Friend WithEvents btnCLICKInheritance As Button
    Friend WithEvents btnCLICKBalUsingPolyMorph As Button
End Class
