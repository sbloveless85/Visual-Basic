﻿Public Class frmISM3232A9LovelessStevenB
    Private Sub btnCLICKInheritance_Click(sender As Object, e As EventArgs) Handles btnCLICKInheritance.Click
        FileOpen(1, "AccountBalancesUsingInheritance.txt", OpenMode.Output)

        Dim Cash As New clsAssetAccount
        Cash.AccountName = "Cash"
        Cash.DebitBalance = 10000
        Cash.CreditBalance = 4000
        Cash.ComputeBalance()
        Print(1, Cash.AccountName & "," & Cash.NetBalance & vbCrLf)

        Dim AR As New clsAssetAccount
        AR.AccountName = "AccountsReceivable"
        AR.DebitBalance = 5000
        AR.CreditBalance = 2000
        AR.ComputeBalance()
        Print(1, AR.AccountName & "," & AR.NetBalance & vbCrLf)

        Dim AP As New clsLiabilityAccount
        AP.AccountName = "AccountsPayable"
        AP.DebitBalance = 6000
        AP.CreditBalance = 8000
        AP.ComputeBalance()
        Print(1, AP.AccountName & "," & AP.NetBalance & vbCrLf)

        Dim RE As New clsEquityAccount
        RE.AccountName = "RetainedEarnings"
        RE.DebitBalance = 7000
        RE.CreditBalance = 14000
        RE.ComputeBalance()
        Print(1, RE.AccountName & "," & RE.NetBalance & vbCrLf)

        FileClose(1)
        MsgBox("Done")
    End Sub

    Private Sub btnCLICKBalUsingPolyMorph_Click(sender As Object, e As EventArgs) Handles btnCLICKBalUsingPolyMorph.Click
        FileOpen(1, "AccountBalancesUsingPolymorphism.txt", OpenMode.Output)

        Dim currentasset As IntAccount

        currentasset = New IAssetAccount
        currentasset.AccountName = "Cash"
        currentasset.DebitBalance = 10000
        currentasset.CreditBalance = 4000
        currentasset.ComputeBalance()
        Print(1, currentasset.AccountName & "," & currentasset.NetBalance & vbCrLf)

        currentasset = New IAssetAccount
        currentasset.AccountName = "AccountsReceivable"
        currentasset.DebitBalance = 5000
        currentasset.CreditBalance = 2000
        currentasset.ComputeBalance()
        Print(1, currentasset.AccountName & "," & currentasset.NetBalance & vbCrLf)

        currentasset = New ILiabilityAccount
        currentasset.AccountName = "AccountsPayable"
        currentasset.DebitBalance = 6000
        currentasset.CreditBalance = 8000
        currentasset.ComputeBalance()
        Print(1, currentasset.AccountName & "," & currentasset.NetBalance & vbCrLf)

        currentasset = New IEquityAccount
        currentasset.AccountName = "RetainedEarnings"
        currentasset.DebitBalance = 7000
        currentasset.CreditBalance = 14000
        currentasset.ComputeBalance()
        Print(1, currentasset.AccountName & "," & currentasset.NetBalance & vbCrLf)

        FileClose(1)
        MsgBox("Done")
    End Sub
End Class
