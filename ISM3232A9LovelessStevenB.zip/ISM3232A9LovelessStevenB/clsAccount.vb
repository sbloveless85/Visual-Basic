﻿Public MustInherit Class clsAccount
    Dim mAccountName As String
    Dim mDebitBalance As Single
    Dim mCreditBalance As Single
    Dim mNetBalance As Single
    Dim mRetainedEarnings As String

    Property AccountName As String
        Get
            Return mAccountName
        End Get
        Set(value As String)
            mAccountName = value
        End Set
    End Property
    Property DebitBalance As Single
        Get
            Return mDebitBalance
        End Get
        Set(value As Single)
            mDebitBalance = value
        End Set
    End Property
    Property CreditBalance As Single
        Get
            Return mCreditBalance
        End Get
        Set(value As Single)
            mCreditBalance = value
        End Set
    End Property
    Property NetBalance As Single
        Get
            Return mNetBalance
        End Get
        Set(value As Single)
            mNetBalance = value
        End Set
    End Property
    Property RetainedEarnings As String
        Get
            Return mRetainedEarnings
        End Get
        Set(value As String)
            mRetainedEarnings = value
        End Set
    End Property
    Overridable Sub ComputeBalance()
        mNetBalance = DebitBalance - CreditBalance
    End Sub
End Class

Class clsAssetAccount
    Inherits clsAccount
End Class

Class clsLiabilityAccount
    Inherits clsAccount
    Public Overrides Sub ComputeBalance()
        NetBalance = CreditBalance - DebitBalance
    End Sub
End Class

Class clsEquityAccount
    Inherits clsAccount
    Public Overrides Sub ComputeBalance()
        NetBalance = CreditBalance - DebitBalance
    End Sub
End Class