﻿Public Interface IntAccount
    Property AccountName() As String
    Property DebitBalance() As Single
    Property CreditBalance() As Single
    Property NetBalance() As Single
    Sub ComputeBalance()
End Interface



Class IAssetAccount
    Implements IntAccount
    Dim mDebit, mCredit As Single
    Dim mAccount, mNetBal As String
    Public Property AccountName As String Implements IntAccount.AccountName
        Get
            Return mAccount
        End Get
        Set(value As String)
            mAccount = value
        End Set
    End Property

    Public Property DebitBalance As Single Implements IntAccount.DebitBalance
        Get
            Return mDebit
        End Get
        Set(value As Single)
            mDebit = value
        End Set
    End Property

    Public Property CreditBalance As Single Implements IntAccount.CreditBalance
        Get
            Return mCredit
        End Get
        Set(value As Single)
            mCredit = value
        End Set
    End Property

    Public Property NetBalance As Single Implements IntAccount.NetBalance
        Get
            Return mNetBal
        End Get
        Set(value As Single)
            mNetBal = value
        End Set
    End Property

    Public Sub ComputeBalance() Implements IntAccount.ComputeBalance
        mNetBal = mDebit - mCredit
    End Sub
End Class
Class ILiabilityAccount
    Implements IntAccount
    Dim mDebit, mCredit As Single
    Dim mAccount, mNetBal As String
    Public Property AccountName As String Implements IntAccount.AccountName
        Get
            Return mAccount
        End Get
        Set(value As String)
            mAccount = value
        End Set
    End Property

    Public Property DebitBalance As Single Implements IntAccount.DebitBalance
        Get
            Return mDebit
        End Get
        Set(value As Single)
            mDebit = value
        End Set
    End Property

    Public Property CreditBalance As Single Implements IntAccount.CreditBalance
        Get
            Return mCredit
        End Get
        Set(value As Single)
            mCredit = value
        End Set
    End Property

    Public Property NetBalance As Single Implements IntAccount.NetBalance
        Get
            Return mNetBal
        End Get
        Set(value As Single)
            mNetBal = value
        End Set
    End Property

    Public Sub ComputeBalance() Implements IntAccount.ComputeBalance
        mNetBal = mCredit - mDebit
    End Sub
End Class
Class IEquityAccount
    Implements IntAccount
    Dim mDebit, mCredit As Single
    Dim mAccount, mNetBal As String
    Public Property AccountName As String Implements IntAccount.AccountName
        Get
            Return mAccount
        End Get
        Set(value As String)
            mAccount = value
        End Set
    End Property

    Public Property DebitBalance As Single Implements IntAccount.DebitBalance
        Get
            Return mDebit
        End Get
        Set(value As Single)
            mDebit = value
        End Set
    End Property

    Public Property CreditBalance As Single Implements IntAccount.CreditBalance
        Get
            Return mCredit
        End Get
        Set(value As Single)
            mCredit = value
        End Set
    End Property

    Public Property NetBalance As Single Implements IntAccount.NetBalance
        Get
            Return mNetBal
        End Get
        Set(value As Single)
            mNetBal = value
        End Set
    End Property

    Public Sub ComputeBalance() Implements IntAccount.ComputeBalance
        mNetBal = mCredit - mDebit
    End Sub
End Class