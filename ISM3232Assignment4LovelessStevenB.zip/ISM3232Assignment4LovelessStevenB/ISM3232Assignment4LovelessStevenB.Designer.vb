﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ISM3232Assignment4LovelessStevenB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblFormDesc = New System.Windows.Forms.Label()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.lblHeight = New System.Windows.Forms.Label()
        Me.txt_Weight = New System.Windows.Forms.TextBox()
        Me.txt_Height = New System.Windows.Forms.TextBox()
        Me.btn_ComputeBMI_WSub = New System.Windows.Forms.Button()
        Me.btn_ComputeBMI_wFunct = New System.Windows.Forms.Button()
        Me.lbl_BMIVal = New System.Windows.Forms.Label()
        Me.lbl_WeightVal = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.lbl_BMIValBox = New System.Windows.Forms.Label()
        Me.lbl_WeightValBox = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblFormDesc
        '
        Me.lblFormDesc.AutoSize = True
        Me.lblFormDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormDesc.Location = New System.Drawing.Point(139, 33)
        Me.lblFormDesc.Name = "lblFormDesc"
        Me.lblFormDesc.Size = New System.Drawing.Size(323, 24)
        Me.lblFormDesc.TabIndex = 0
        Me.lblFormDesc.Text = "Assignment 4 By Steven Loveless"
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWeight.Location = New System.Drawing.Point(112, 104)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(98, 16)
        Me.lblWeight.TabIndex = 1
        Me.lblWeight.Text = "Weight (in lbs.):"
        '
        'lblHeight
        '
        Me.lblHeight.AutoSize = True
        Me.lblHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeight.Location = New System.Drawing.Point(112, 141)
        Me.lblHeight.Name = "lblHeight"
        Me.lblHeight.Size = New System.Drawing.Size(113, 16)
        Me.lblHeight.TabIndex = 2
        Me.lblHeight.Text = "Height (in inches):"
        '
        'txt_Weight
        '
        Me.txt_Weight.Location = New System.Drawing.Point(356, 104)
        Me.txt_Weight.MinimumSize = New System.Drawing.Size(150, 20)
        Me.txt_Weight.Name = "txt_Weight"
        Me.txt_Weight.Size = New System.Drawing.Size(150, 20)
        Me.txt_Weight.TabIndex = 3
        '
        'txt_Height
        '
        Me.txt_Height.Location = New System.Drawing.Point(356, 141)
        Me.txt_Height.MinimumSize = New System.Drawing.Size(150, 20)
        Me.txt_Height.Name = "txt_Height"
        Me.txt_Height.Size = New System.Drawing.Size(150, 20)
        Me.txt_Height.TabIndex = 4
        '
        'btn_ComputeBMI_WSub
        '
        Me.btn_ComputeBMI_WSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ComputeBMI_WSub.Location = New System.Drawing.Point(114, 191)
        Me.btn_ComputeBMI_WSub.MinimumSize = New System.Drawing.Size(150, 60)
        Me.btn_ComputeBMI_WSub.Name = "btn_ComputeBMI_WSub"
        Me.btn_ComputeBMI_WSub.Size = New System.Drawing.Size(150, 60)
        Me.btn_ComputeBMI_WSub.TabIndex = 5
        Me.btn_ComputeBMI_WSub.Text = "Compute BMI Using Sub"
        Me.btn_ComputeBMI_WSub.UseVisualStyleBackColor = True
        '
        'btn_ComputeBMI_wFunct
        '
        Me.btn_ComputeBMI_wFunct.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ComputeBMI_wFunct.Location = New System.Drawing.Point(356, 191)
        Me.btn_ComputeBMI_wFunct.MinimumSize = New System.Drawing.Size(150, 60)
        Me.btn_ComputeBMI_wFunct.Name = "btn_ComputeBMI_wFunct"
        Me.btn_ComputeBMI_wFunct.Size = New System.Drawing.Size(150, 60)
        Me.btn_ComputeBMI_wFunct.TabIndex = 6
        Me.btn_ComputeBMI_wFunct.Text = "Compute BMI Using Function"
        Me.btn_ComputeBMI_wFunct.UseVisualStyleBackColor = True
        '
        'lbl_BMIVal
        '
        Me.lbl_BMIVal.AutoSize = True
        Me.lbl_BMIVal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_BMIVal.Location = New System.Drawing.Point(111, 277)
        Me.lbl_BMIVal.Name = "lbl_BMIVal"
        Me.lbl_BMIVal.Size = New System.Drawing.Size(114, 16)
        Me.lbl_BMIVal.TabIndex = 7
        Me.lbl_BMIVal.Text = "Your BMI value is:"
        '
        'lbl_WeightVal
        '
        Me.lbl_WeightVal.AutoSize = True
        Me.lbl_WeightVal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_WeightVal.Location = New System.Drawing.Point(111, 317)
        Me.lbl_WeightVal.Name = "lbl_WeightVal"
        Me.lbl_WeightVal.Size = New System.Drawing.Size(131, 16)
        Me.lbl_WeightVal.TabIndex = 8
        Me.lbl_WeightVal.Text = "Your weight status is:"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(114, 365)
        Me.btnClear.MinimumSize = New System.Drawing.Size(150, 60)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(150, 60)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuit.Location = New System.Drawing.Point(356, 365)
        Me.btnQuit.MinimumSize = New System.Drawing.Size(150, 60)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(150, 60)
        Me.btnQuit.TabIndex = 10
        Me.btnQuit.Text = "Quit"
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'lbl_BMIValBox
        '
        Me.lbl_BMIValBox.AutoSize = True
        Me.lbl_BMIValBox.BackColor = System.Drawing.SystemColors.Control
        Me.lbl_BMIValBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_BMIValBox.Location = New System.Drawing.Point(356, 277)
        Me.lbl_BMIValBox.MinimumSize = New System.Drawing.Size(150, 20)
        Me.lbl_BMIValBox.Name = "lbl_BMIValBox"
        Me.lbl_BMIValBox.Size = New System.Drawing.Size(150, 20)
        Me.lbl_BMIValBox.TabIndex = 11
        Me.lbl_BMIValBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_WeightValBox
        '
        Me.lbl_WeightValBox.AutoSize = True
        Me.lbl_WeightValBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_WeightValBox.Location = New System.Drawing.Point(356, 314)
        Me.lbl_WeightValBox.MinimumSize = New System.Drawing.Size(150, 20)
        Me.lbl_WeightValBox.Name = "lbl_WeightValBox"
        Me.lbl_WeightValBox.Size = New System.Drawing.Size(150, 20)
        Me.lbl_WeightValBox.TabIndex = 12
        Me.lbl_WeightValBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ISM3232Assignment4LovelessStevenB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 461)
        Me.Controls.Add(Me.lbl_WeightValBox)
        Me.Controls.Add(Me.lbl_BMIValBox)
        Me.Controls.Add(Me.btnQuit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lbl_WeightVal)
        Me.Controls.Add(Me.lbl_BMIVal)
        Me.Controls.Add(Me.btn_ComputeBMI_wFunct)
        Me.Controls.Add(Me.btn_ComputeBMI_WSub)
        Me.Controls.Add(Me.txt_Height)
        Me.Controls.Add(Me.txt_Weight)
        Me.Controls.Add(Me.lblHeight)
        Me.Controls.Add(Me.lblWeight)
        Me.Controls.Add(Me.lblFormDesc)
        Me.MinimumSize = New System.Drawing.Size(600, 500)
        Me.Name = "ISM3232Assignment4LovelessStevenB"
        Me.Text = "ISM3232Assignment4LovelessStevenB"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblFormDesc As Label
    Friend WithEvents lblWeight As Label
    Friend WithEvents lblHeight As Label
    Friend WithEvents txt_Weight As TextBox
    Friend WithEvents txt_Height As TextBox
    Friend WithEvents btn_ComputeBMI_WSub As Button
    Friend WithEvents btn_ComputeBMI_wFunct As Button
    Friend WithEvents lbl_BMIVal As Label
    Friend WithEvents lbl_WeightVal As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnQuit As Button
    Friend WithEvents lbl_BMIValBox As Label
    Friend WithEvents lbl_WeightValBox As Label
End Class
