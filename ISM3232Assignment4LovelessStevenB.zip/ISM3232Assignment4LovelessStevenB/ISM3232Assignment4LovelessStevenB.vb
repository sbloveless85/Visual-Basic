﻿Public Class ISM3232Assignment4LovelessStevenB
    Function UserBMI(ByVal UserWeight, ByVal UserHeight) As String
        Return (UserWeight * 703) / (UserHeight ^ 2)
    End Function
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_ComputeBMI_WSub.Click
        If txt_Weight.Text = "" Or
                 txt_Height.Text = "" Then
            MsgBox("Please enter your height and weight before clicking this button.")
            Exit Sub
        End If

        Dim UserWeight As String
        UserWeight = CStr(txt_Weight.Text)
        Dim UserHeight As String
        UserHeight = CStr(txt_Height.Text)

        Dim UserBMI As Double
        UserBMI = (CStr(UserWeight * 703) / CStr(UserHeight) ^ 2)
        lbl_BMIValBox.Text = UserBMI

        Select Case UserBMI
            Case Is >= 30
                lbl_WeightValBox.Text = "You are obese."
            Case Is >= 25
                lbl_WeightValBox.Text = "You are overweight."
            Case Is >= 18.5
                lbl_WeightValBox.Text = "Your weight is normal."
            Case Is <= 18.5
                lbl_WeightValBox.Text = "You are underweight."
        End Select
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lbl_BMIValBox.Text = ""
        lbl_WeightValBox.Text = ""
        txt_Height.Text = ""
        txt_Weight.Text = ""
    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        End
    End Sub

    Private Sub btn_ComputeBMI_wFunct_Click(sender As Object, e As EventArgs) Handles btn_ComputeBMI_wFunct.Click
        If txt_Weight.Text = "" Or
               txt_Height.Text = "" Then
            MsgBox("Please enter your height and weight before clicking this button.")
            Exit Sub
        End If
        Dim UserWeight As String
        UserWeight = CStr(txt_Weight.Text)
        Dim UserHeight As String
        UserHeight = CStr(txt_Height.Text)

        lbl_BMIValBox.Text = UserBMI(UserWeight, UserHeight)

        Select Case UserBMI(UserWeight, UserHeight)
            Case Is >= 30
                lbl_WeightValBox.Text = "You are obese."
            Case Is >= 25
                lbl_WeightValBox.Text = "You are overweight."
            Case Is >= 18.5
                lbl_WeightValBox.Text = "Your weight is normal."
            Case Is <= 18.5
                lbl_WeightValBox.Text = "You are underweight."
        End Select
    End Sub
End Class
